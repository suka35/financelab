for i = 1 : 417
    invF(:,:,i) = inv(FF(:,:,i));
end
